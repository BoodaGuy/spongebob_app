package com.example.spongebobcharacters;

public interface OnSelectedCharacter {
    void onClickedChar(Characters character);
}
